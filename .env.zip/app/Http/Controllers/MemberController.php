<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $query = Member::with('group')->orderByDesc('created_at');
        if (request('group_id')) {
            $query->where('group_id', request('group_id'));
        }
        return $query->get();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'first_name' => ['required','string','max:255'],
            'last_name' => ['required','string','max:255'],
            'birth_date' => ['required','date'],
            'gender' => ['required','in:MALE,FEMALE,OTHER'],
            'is_active' => ['required','boolean'],
            'national_id' => ['required','string','max:255','unique:members,national_id'],
            'phone' => ['required','string','max:50'],
            'group_id' => ['required','exists:groups,id'],
        ]);
        $member = Member::create($data);
        return response()->json($member, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Member $member)
    {
        return $member->load('group');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Member $member)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Member $member)
    {
        $data = $request->validate([
            'first_name' => ['sometimes','string','max:255'],
            'last_name' => ['sometimes','string','max:255'],
            'birth_date' => ['sometimes','date'],
            'gender' => ['sometimes','in:MALE,FEMALE,OTHER'],
            'is_active' => ['sometimes','boolean'],
            'national_id' => ['sometimes','string','max:255','unique:members,national_id,'.$member->id],
            'phone' => ['sometimes','string','max:50'],
            'group_id' => ['sometimes','exists:groups,id'],
        ]);
        $member->update($data);
        return $member->load('group');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Member $member)
    {
        $member->delete();
        return response()->noContent();
    }
}
