<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\CustomerInfoController;

Route::get('/hello', function () {
    return ['status' => 'ok'];
});

Route::apiResource('groups', GroupController::class);
Route::apiResource('members', MemberController::class);
Route::get('customer-info', [CustomerInfoController::class, 'show']);